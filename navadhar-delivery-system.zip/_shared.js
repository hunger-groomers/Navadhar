// NAVADHAR SHARED DATA LAYER
const CENTER = { lat: 26.2389, lng: 73.0243 };

const ZONE_META = {
  North: { label: 'N', solid: '#2563EB', light: 'rgba(37,99,235,0.15)', text: '#93c5fd', vehicles: ['VH-N01'], emoji: '▲' },
  East:  { label: 'E', solid: '#059669', light: 'rgba(5,150,105,0.15)',  text: '#6ee7b7', vehicles: ['VH-E01'], emoji: '▶' },
  South: { label: 'S', solid: '#D97706', light: 'rgba(217,119,6,0.15)', text: '#fcd34d', vehicles: ['VH-S01'], emoji: '▼' },
  West:  { label: 'W', solid: '#E05A2B', light: 'rgba(224,90,43,0.15)', text: '#fca5a5', vehicles: ['VH-W01'], emoji: '◀' }
};

function haversine(la1, lo1, la2, lo2) {
  const R = 6371000, d1 = (la2 - la1) * Math.PI / 180, d2 = (lo2 - lo1) * Math.PI / 180;
  const a = Math.sin(d1/2)**2 + Math.cos(la1*Math.PI/180) * Math.cos(la2*Math.PI/180) * Math.sin(d2/2)**2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function getZone(lat, lng) {
  const dLat = lat - CENTER.lat, dLng = lng - CENTER.lng;
  return Math.abs(dLat) > Math.abs(dLng) ? (dLat > 0 ? 'North' : 'South') : (dLng > 0 ? 'East' : 'West');
}

function loadPickups() {
  try { return JSON.parse(localStorage.getItem('nvd_pickups') || '[]'); } catch(e) { return []; }
}

function savePickups(data) {
  try { localStorage.setItem('nvd_pickups', JSON.stringify(data)); } catch(e) {}
}

function zonePickups(zone, all) {
  return (all || loadPickups()).filter(p => p.zone === zone).sort((a, b) => a.dist - b.dist);
}
